Splitting();
const typed = new Typed(".typing .txt", {
  strings: [
    "ToGather <strong>에서</strong>",
    "자기개발과<strong>취미생활을</strong>",
    "시작해보세요<strong>:)</strong>.",
    "my name is <strong>Sung gyu</strong>",
    "keep an <strong>eyes on me.</strong>",
  ],
  typeSpeed: 50,
  startDelay: 1000,
  backSpeed: 20,
  backDelay: 3000,
  loop: true,
});

gsap.defaults({
  duration: 1,
  ease: "back",
});
ScrollTrigger.defaults({
  //markers: true,
});
