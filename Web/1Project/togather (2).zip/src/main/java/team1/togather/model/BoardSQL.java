package team1.togather.model;

public class BoardSQL {
	final static String SELECT="select * from BOARD order by bnum desc";
}
