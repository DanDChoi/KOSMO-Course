package team1.togather.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;
import team1.togather.domain.Gathering;
import team1.togather.service.GatheringService;

@Log4j
@Controller
@AllArgsConstructor
@RequestMapping("/gathering/")
public class GatheringController {
	
	private GatheringService gatheringService;
	
	@GetMapping("/gatheringList.do") //정모 목록
	public ModelAndView list() {
		List<Gathering> list = gatheringService.ga_selectAllS();
		ModelAndView mv = new ModelAndView("gathering/list", "list", list);
		return mv;
	}
	@GetMapping("/gatheringInfo.do") //정모 디테일
	public ModelAndView gatheringInfo(long ga_seq) {
		Gathering gatheringInfo = gatheringService.ga_selectByGaSeqS(ga_seq);
		ModelAndView mv = new ModelAndView("gathering/gatheringInfo", "gatheringInfo", gatheringInfo);
		return mv;
	}
	
	@PostMapping("/gatheringCreate.do") //정모 만들기
	public String gatheringCreate() {
		return "gathering/gatheringCreate";
	}
	
	@GetMapping("/gatheringDelete.do") //정모삭제
	public String gatheringDelete(long ga_seq) {
		gatheringService.ga_deleteS(ga_seq);
		return "redirect:../";
	}
	
	@GetMapping("/getheringUpdate.do")
	public ModelAndView gatheringUpdate(long ga_seq) {
		Gathering updateList = gatheringService.ga_selectByGaSeqS(ga_seq);
		ModelAndView mv = new ModelAndView("gathering/gatheringUpdate", "updateList", updateList);
		return mv;
	}
	
	@PostMapping("/gatheringUpdate.do")
	public String gatheringUpdate(Gathering gathering, HttpServletRequest request) {
		long ga_seq = getGaSeq(request);
		
		gatheringService.ga_updateS(gathering);
		return "redirect:gatheringInfo.do?ga_seq="+ga_seq;
	}
	
	private long getGaSeq(HttpServletRequest request) {
		long ga_seq = -1;
		String ga_seqStr = request.getParameter("ga_seq");
		if(ga_seqStr != null) {
			ga_seqStr = ga_seqStr.trim();
			if(ga_seqStr.length() != 0) {
				try {
					ga_seq = Long.parseLong(ga_seqStr);
					return ga_seq;
				}catch(NumberFormatException nfe) {}
			}
		}
		return ga_seq;
	}
	
	
}
