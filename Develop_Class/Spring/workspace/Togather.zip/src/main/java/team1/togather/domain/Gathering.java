package team1.togather.domain;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Gathering {
	private long ga_seq;
	private String ga_name;
	private Date ga_date;
	private String time;
	private String ga_place;
	private String price;
	private int ga_limit;
	private long gseq;
	private long mnum;
	
}
