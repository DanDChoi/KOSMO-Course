package team1.togather.mapper;

import team1.togather.domain.Member;

public interface MemberMapper {
	int join(Member member);
	int joincheck(String phone);
	int joincheck2(String email);
	Member logincheck(Member member);
	int kakaologincheck(Member member);
	Member kakaologin(Member member);
}
