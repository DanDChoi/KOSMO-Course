package team1.togather.service;

import java.util.List;

import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import team1.togather.domain.Gathering;
import team1.togather.mapper.GatheringMapper;

@Service
@AllArgsConstructor
public class GatheringServiceImpl implements GatheringService {
	
	private GatheringMapper gatheringMapper;

	@Override
	public List<Gathering> ga_selectAllS() {
		List<Gathering> list = gatheringMapper.ga_selectAll();
		return list;
	}

	@Override
	public Gathering ga_selectByGaSeqS(long ga_seq) {
		return gatheringMapper.ga_selectByGaSeq(ga_seq);
	}

	@Override
	public void ga_insertS(Gathering gathering) {
		gatheringMapper.ga_insert(gathering);

	}

	@Override
	public void ga_updateS(Gathering gathering) {
		gatheringMapper.ga_update(gathering);

	}

	@Override
	public void ga_deleteS(long ga_seq) {
		gatheringMapper.ga_delete(ga_seq);

	}

}
