package team1.togather.service;

import java.util.List;

import team1.togather.domain.Gathering;

public interface GatheringService {
	List<Gathering> ga_selectAllS();
	Gathering ga_selectByGaSeqS(long ga_seq);
	void ga_insertS(Gathering gathering);
	void ga_updateS(Gathering gathering);
	void ga_deleteS(long ga_seq);
}
