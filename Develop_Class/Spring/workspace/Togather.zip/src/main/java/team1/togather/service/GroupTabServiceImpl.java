package team1.togather.service;

import java.util.List;

import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import team1.togather.domain.GroupTab;
import team1.togather.mapper.GroupTabMapper;

@Service
@AllArgsConstructor
public class GroupTabServiceImpl implements GroupTabService {
	private GroupTabMapper groupTabMapper;
	
	@Override
	public List<GroupTab> selectAllS() {
		List<GroupTab> list = groupTabMapper.selectAll();
		return list;
	}

	@Override
	public GroupTab selectByGSeqS(long gseq) {
		return groupTabMapper.selectByGSeq(gseq);
	}

	@Override
	public void insertS(GroupTab groupTab) {
		groupTabMapper.insert(groupTab);
	}

	@Override
	public void updateS(GroupTab groupTab) {
		groupTabMapper.update(groupTab);
	}

	@Override
	public void deleteS(long gseq) {
		groupTabMapper.delete(gseq);
	}

	

}