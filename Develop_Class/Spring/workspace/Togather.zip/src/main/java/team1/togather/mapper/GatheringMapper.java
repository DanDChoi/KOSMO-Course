package team1.togather.mapper;

import java.util.List;

import team1.togather.domain.Gathering;

public interface GatheringMapper {
	List<Gathering> ga_selectAll();
	Gathering ga_selectByGaSeq(long ga_seq);
	void ga_insert(Gathering gathering);
	void ga_update(Gathering gathering);
	void ga_delete(long ga_seq);
}
