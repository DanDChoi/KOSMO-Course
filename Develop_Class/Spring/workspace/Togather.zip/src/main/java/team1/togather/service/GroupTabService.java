package team1.togather.service;

import java.util.List;

import team1.togather.domain.GroupTab;

public interface GroupTabService {
	List<GroupTab> selectAllS();
	GroupTab selectByGSeqS(long gseq);
	void insertS(GroupTab groupTab);
	void updateS(GroupTab groupTab);
	void deleteS(long gseq);
}