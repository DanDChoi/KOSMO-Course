package team1.togather.service;

import javax.servlet.http.HttpSession;

import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;
import team1.togather.domain.Member;
import team1.togather.mapper.MemberMapper;

@Service
@AllArgsConstructor
public class MemberServiceImpl implements MemberService {
	private MemberMapper mapper;
	@Override
	public int join(Member member) {
		
		int join = 0;
		int joincheck = mapper.joincheck(member.getPhone());
		System.out.println("joincheck: "+joincheck);
		System.out.println("member.getPhone(): "+member.getPhone());
		int joincheck2 = mapper.joincheck2(member.getEmail());
		System.out.println("joincheck2: "+joincheck2);
		System.out.println("member.getEmail(): "+member.getEmail());
		if(joincheck==0 && joincheck2==0) {
			System.out.println("암호화 전 비밀번호 : "+member.getPwd());
			String encrypted = BCrypt.hashpw(member.getPwd(), BCrypt.gensalt());
			System.out.println("암호화 후 비밀번호 : "+member.getPwd());
			member.setPwd(encrypted);
			join = mapper.join(member);
			System.out.println(member.getMnum());
			System.out.println("주소 : " +member.getMaddr());
			System.out.println("관심지역 :"+member.getPfr_loc());
			System.out.println("이름 : "+member.getMname());
			System.out.println("성별 : "+member.getGender());
			System.out.println("생일 : "+member.getBirth());
			System.out.println("데이터베이스 들어간 후 비밀번호 : "+member.getPwd());
			System.out.println("이메일 : " +member.getEmail());
			System.out.println("폰번호 : " +member.getPhone());
			System.out.println("카테고리 : " +member.getCategory());
			System.out.println("이건뭐임 : " +member.getAthur());
			join = 0;
		}else if(joincheck==1){
			join =1;	
		}else if(joincheck2==1) {
			join=2;
		}
		return join;
	}
	@Override
	public int joincheck(String phone) {
		int joincheck = mapper.joincheck(phone);
		return joincheck;
	}
	@Override
	public int joincheck2(String email) {
		int joincheck = mapper.joincheck2(email);
		return joincheck;
	}
	@Override
	public int logincheck(Member member) {
		Member m = mapper.logincheck(member);
		if(m==null) {//아이디없음
			System.out.println("입력된 비밀번호 : "+member.getPwd());
			System.out.println("널일때 m: "+m);
			return 0;
		}else if(!BCrypt.checkpw(member.getPwd(), m.getPwd())) {//비번다를때
			System.out.println("비번다를 때 m: "+m);
			return 1;
		}else {//로그인성공
			System.out.println("else m: "+m);
			return 2;
		}
	}
	@Override
	public Member login(Member member) {
		Member m = mapper.logincheck(member);
		return m;
	}
	@Override
	public int kakaologincheck(Member member) {
		int kakaologincheck = mapper.kakaologincheck(member);
		
		return kakaologincheck;
	}
	@Override
	public Member kakaologin(Member member) {
		Member m = mapper.kakaologin(member);
		return m;
	}
	
}
