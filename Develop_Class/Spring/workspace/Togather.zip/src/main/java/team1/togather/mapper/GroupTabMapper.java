package team1.togather.mapper;

import java.util.List;

import team1.togather.domain.GroupTab;

public interface GroupTabMapper {
	List<GroupTab> selectAll();
	GroupTab selectByGSeq(long gseq);
	void insert(GroupTab groupTab);
	void update(GroupTab groupTab);
	void delete(long gseq);
}
