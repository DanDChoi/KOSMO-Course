package team1.togather.controller;

import javax.servlet.http.HttpSession;

import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import lombok.AllArgsConstructor;
import team1.togather.domain.Member;
import team1.togather.mapper.MemberMapper;
import team1.togather.service.MemberService;



@Controller
@AllArgsConstructor
@RequestMapping("/member/")
public class MemberController {
	private MemberService service;
	
	@GetMapping("/joinform.do")
	public String join() {
		return "member/join";
	}
	
	
	@PostMapping("/join")
	@ResponseBody
	public int join(Member member) {
		int join = service.join(member);
		System.out.println("join :"+join);
		return join;
	}
	
	@GetMapping("/login.do")
	public String login() {
		return "member/login";
	}
	
	@PostMapping("/login")
	@ResponseBody
	public int logincheck(Member member,HttpSession session) {
		//login.jsp에 아이디 확인 반환 로직
		//int 에서 모델앤뷰로 바꿔서 리턴해주기 
		 int logincheck = service.logincheck(member);
		
		if(logincheck==0) {//아이디없음
			
			return logincheck;
		}else if(logincheck==1) {//비번다를때
			
			return logincheck;
		}else {//로그인성공
			Member m = service.login(member);
			session.setAttribute("m", m);
			return  logincheck;
		}
	}
	
	@PostMapping("/kakaologin")
	@ResponseBody
	public int kakaologincheck(Member member,HttpSession session) {
		//login.jsp에 아이디 확인 반환 로직

		 int kakaologincheck = service.kakaologincheck(member);
		
		if(kakaologincheck==0) {//아이디없음
			
			return kakaologincheck;
		}else {//로그인성공
			Member m = service.kakaologin(member);
			session.setAttribute("m", m);
			System.out.println("로그인성공");
			return  kakaologincheck;
		}
	}
	@GetMapping("/logout.do")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
}
