package soo.md.service;

public interface SampleLogService {
	int add(String str1, String str2) throws Exception;
}
