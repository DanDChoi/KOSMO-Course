package soo.md.service;

public interface TxSampleService {
	void addDatas(String data);
}
