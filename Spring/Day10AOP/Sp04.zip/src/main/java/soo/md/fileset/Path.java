package soo.md.fileset;

public class Path {
	public static final String FILE_STORE ="C:/SOO/Spring/upload/tmp/";
}