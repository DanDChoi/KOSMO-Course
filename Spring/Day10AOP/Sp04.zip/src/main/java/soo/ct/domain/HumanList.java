package soo.ct.domain;

import java.util.ArrayList;

import lombok.Data;

@Data
public class HumanList {
	private String dump; //추가
	private ArrayList<Human> list;
}
